using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using LiveMonitor.Data.Models;

namespace LiveMonitor.Data
{
    /// <summary>
    /// High-level data service that provides typed dashboard data.
    /// Wraps QueryExecutor to map raw query results to domain models.
    /// </summary>
    public class DashboardDataService
    {
        private readonly QueryExecutor _executor;
        private readonly DashboardConfigService _configService;

        public DashboardDataService(QueryExecutor executor, DashboardConfigService configService)
        {
            _executor = executor ?? throw new ArgumentNullException(nameof(executor));
            _configService = configService ?? throw new ArgumentNullException(nameof(configService));
        }

        // ================================================================
        // INSTANCES
        // ================================================================

        /// <summary>
        /// Returns the list of active SQL Server instances available for monitoring.
        /// </summary>
        public async Task<string[]> GetInstancesAsync()
        {
            // Use a minimal filter since the instances query does not use time/instance params
            var filter = new DashboardFilter();
            var dt = await _executor.ExecuteQueryAsync("instances.list", filter);
            return dt.Rows.Cast<DataRow>()
                .Select(r => r["sql_instance"]?.ToString() ?? "")
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .ToArray();
        }

        

        // ================================================================
        // LONG QUERIES
        // ================================================================

        /// <summary>
        /// Returns long query count over time from the first TimeSeries panel in longqueries dashboard.
        /// </summary>
        public async Task<List<TimeSeriesPoint>> GetLongQueryTimeSeriesAsync(DashboardFilter filter)
        {
            var queryId = FindFirstPanelQuery("longqueries", "TimeSeries");
            return await _executor.ExecuteQueryAsync(queryId, filter, MapTimeSeriesPoint);
        }

        /// <summary>
        /// Returns full details table for long-running queries from the first DataGrid panel in longqueries dashboard.
        /// </summary>
        public async Task<DataTable> GetLongQueryDetailsAsync(DashboardFilter filter)
        {
            var queryId = FindFirstPanelQuery("longqueries", "DataGrid");
            return await _executor.ExecuteQueryAsync(queryId, filter);
        }

        /// <summary>
        /// Returns SQL text and query plan for a specific long query by its ID from the query text panel.
        /// </summary>
        public async Task<string> GetLongQueryTextAsync(DashboardFilter filter, int queryId)
        {
            var extra = new Dictionary<string, object> { ["@QueryId"] = FindPanelQueryById("longqueries", "longqueries.querytext") };
            var dt = await _executor.ExecuteQueryAsync(FindPanelQueryById("longqueries", "longqueries.querytext"), filter, extra);
            if (dt.Rows.Count > 0)
                return dt.Rows[0]["statement"]?.ToString() ?? "";
            return "";
        }

        // ================================================================
        // HELPER METHODS
        // ================================================================

        /// <summary>
        /// Finds the first panel query ID in a dashboard by panel type.
        /// </summary>
        private string FindFirstPanelQuery(string dashboardId, string panelType)
        {
            var dashboard = _configService.Config.Dashboards.FirstOrDefault(d => d.Id == dashboardId);
            var panel = dashboard?.Panels.FirstOrDefault(p => p.PanelType == panelType && p.Enabled);
            return panel?.Id ?? throw new InvalidOperationException($"No enabled {panelType} panel found in {dashboardId} dashboard");
        }

        /// <summary>
        /// Finds a specific panel query ID by panel ID in a dashboard.
        /// </summary>
        private string FindPanelQueryById(string dashboardId, string panelId)
        {
            var dashboard = _configService.Config.Dashboards.FirstOrDefault(d => d.Id == dashboardId);
            var panel = dashboard?.Panels.FirstOrDefault(p => p.Id == panelId && p.Enabled);
            return panel?.Id ?? throw new InvalidOperationException($"Panel {panelId} not found or not enabled in {dashboardId} dashboard");
        }

        // ================================================================
        // WAIT EVENTS
        // ================================================================

        /// <summary>
        /// Returns wait event duration time series from first TimeSeries panel in waitevents dashboard.
        /// </summary>
        public async Task<List<TimeSeriesPoint>> GetWaitEventsTimeSeriesAsync(DashboardFilter filter)
        {
            var queryId = FindFirstPanelQuery("waitevents", "TimeSeries");
            return await _executor.ExecuteQueryAsync(queryId, filter, MapTimeSeriesPoint);
        }

        /// <summary>
        /// Returns detailed wait event data from first DataGrid panel in waitevents dashboard.
        /// </summary>
        public async Task<DataTable> GetWaitEventDetailsAsync(DashboardFilter filter)
        {
            var queryId = FindFirstPanelQuery("waitevents", "DataGrid");
            return await _executor.ExecuteQueryAsync(queryId, filter);
        }

       
        // ================================================================
        // SHARED MAPPER
        // ================================================================

        /// <summary>
        /// Maps a data reader row with Time/Series/Value columns to a TimeSeriesPoint.
        /// </summary>
        private static TimeSeriesPoint MapTimeSeriesPoint(IDataReader reader)
        {
            return new TimeSeriesPoint
            {
                Time = ParseDateTime(reader["Time"]),
                Series = reader["Series"]?.ToString() ?? "",
                Value = reader["Value"] != DBNull.Value ? Convert.ToDouble(reader["Value"]) : 0.0
            };
        }

        /// <summary>
        /// Parses a DateTime from either a DateTime object or a string (ISO 8601 format).
        /// </summary>
        private static DateTime ParseDateTime(object? value)
        {
            if (value == null || value == DBNull.Value)
                return DateTime.MinValue;

            if (value is DateTime dt)
                return dt;

            if (DateTime.TryParse(value.ToString(), out var parsed))
                return parsed;

            return DateTime.MinValue;
        }
    }
}
