using System.Data;
using System.Data.SqlClient;

namespace LiveMonitor.Data
{
    public class SqlServerConnectionFactory : IDbConnectionFactory
    {
        private readonly string _connectionString;

        public SqlServerConnectionFactory(string connectionString)
        {
            _connectionString = connectionString;
        }

        public IDbConnection CreateConnection() => new SqlConnection(_connectionString);
        public string DataSourceType => "SqlServer";
    }
}
