using System.Data;

namespace LiveMonitor.Data
{
    public interface IDbConnectionFactory
    {
        IDbConnection CreateConnection();
        string DataSourceType { get; } // "SqlServer" or "Sqlite"
    }
}
