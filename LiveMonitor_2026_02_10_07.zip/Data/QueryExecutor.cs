using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using LiveMonitor.Data.Models;

namespace LiveMonitor.Data
{
    /// <summary>
    /// Executes parameterized queries from the QueryStore against the configured database.
    /// Uses SQL Server via System.Data.SqlClient.
    /// </summary>
    public class QueryExecutor
    {
        private readonly IDbConnectionFactory _connectionFactory;
        private readonly QueryStore _queryStore;

        public QueryExecutor(IDbConnectionFactory connectionFactory, QueryStore queryStore)
        {
            _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
            _queryStore = queryStore ?? throw new ArgumentNullException(nameof(queryStore));
        }

        /// <summary>
        /// Executes a query by ID with the given filter parameters and returns a DataTable.
        /// </summary>
        /// <param name="queryId">The query identifier from the QueryStore.</param>
        /// <param name="filter">Dashboard filter containing time range, instance, and other parameters.</param>
        /// <param name="additionalParams">Optional extra parameters (e.g., @QueryId, @PlanHash).</param>
        /// <returns>A DataTable containing the query results.</returns>
        public async Task<DataTable> ExecuteQueryAsync(
            string queryId,
            DashboardFilter filter,
            Dictionary<string, object>? additionalParams = null)
        {
            var sql = _queryStore.GetQuery(queryId, _connectionFactory.DataSourceType);
            var dt = new DataTable();

            await Task.Run(() =>
            {
                using var conn = _connectionFactory.CreateConnection();
                conn.Open();

                using var cmd = conn.CreateCommand();
                cmd.CommandText = sql;
                cmd.CommandTimeout = 30;

                AddFilterParameters(cmd, filter);

                if (additionalParams != null)
                {
                    foreach (var kvp in additionalParams)
                    {
                        AddParameter(cmd, kvp.Key, kvp.Value);
                    }
                }

                using var reader = cmd.ExecuteReader();
                dt.Load(reader);
            });

            return dt;
        }

        /// <summary>
        /// Executes a query by ID and maps each row to a typed object using the provided mapper function.
        /// </summary>
        /// <typeparam name="T">The target type to map each row to.</typeparam>
        /// <param name="queryId">The query identifier from the QueryStore.</param>
        /// <param name="filter">Dashboard filter containing time range, instance, and other parameters.</param>
        /// <param name="mapper">A function that maps an IDataReader row to an instance of T.</param>
        /// <param name="additionalParams">Optional extra parameters (e.g., @QueryId, @PlanHash).</param>
        /// <returns>A list of mapped objects.</returns>
        public async Task<List<T>> ExecuteQueryAsync<T>(
            string queryId,
            DashboardFilter filter,
            Func<IDataReader, T> mapper,
            Dictionary<string, object>? additionalParams = null)
        {
            var sql = _queryStore.GetQuery(queryId, _connectionFactory.DataSourceType);
            var results = new List<T>();

            await Task.Run(() =>
            {
                using var conn = _connectionFactory.CreateConnection();
                conn.Open();

                using var cmd = conn.CreateCommand();
                cmd.CommandText = sql;
                cmd.CommandTimeout = 30;

                AddFilterParameters(cmd, filter);

                if (additionalParams != null)
                {
                    foreach (var kvp in additionalParams)
                    {
                        AddParameter(cmd, kvp.Key, kvp.Value);
                    }
                }

                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    results.Add(mapper(reader));
                }
            });

            return results;
        }

        /// <summary>
        /// Executes a query and returns a single scalar value.
        /// </summary>
        /// <typeparam name="T">The expected return type.</typeparam>
        /// <param name="queryId">The query identifier from the QueryStore.</param>
        /// <param name="filter">Dashboard filter containing time range, instance, and other parameters.</param>
        /// <param name="additionalParams">Optional extra parameters.</param>
        /// <returns>The scalar value, or default(T) if no result.</returns>
        public async Task<T?> ExecuteScalarAsync<T>(
            string queryId,
            DashboardFilter filter,
            Dictionary<string, object>? additionalParams = null)
        {
            var sql = _queryStore.GetQuery(queryId, _connectionFactory.DataSourceType);

            return await Task.Run(() =>
            {
                using var conn = _connectionFactory.CreateConnection();
                conn.Open();

                using var cmd = conn.CreateCommand();
                cmd.CommandText = sql;
                cmd.CommandTimeout = 30;

                AddFilterParameters(cmd, filter);

                if (additionalParams != null)
                {
                    foreach (var kvp in additionalParams)
                    {
                        AddParameter(cmd, kvp.Key, kvp.Value);
                    }
                }

                var result = cmd.ExecuteScalar();
                if (result == null || result == DBNull.Value)
                    return default;

                return (T)Convert.ChangeType(result, typeof(T));
            });
        }

        /// <summary>
        /// Adds the standard dashboard filter parameters to the command.
        /// @SqlInstance is a comma-separated string used with STRING_SPLIT in SQL Server queries.
        /// </summary>
        private void AddFilterParameters(IDbCommand cmd, DashboardFilter filter)
        {
            AddParameter(cmd, "@TimeFrom", filter.TimeFrom.ToString("yyyy-MM-dd HH:mm:ss"));
            AddParameter(cmd, "@TimeTo", filter.TimeTo.ToString("yyyy-MM-dd HH:mm:ss"));

            // SQL Server queries use STRING_SPLIT(@SqlInstance, ',')
            var joined = filter.Instances.Length > 0 ? string.Join(",", filter.Instances) : "";
            AddParameter(cmd, "@SqlInstance", joined);

            AddParameter(cmd, "@AggMin", filter.AggregationMinutes);
        }

        /// <summary>
        /// Adds a parameter to the command in a provider-agnostic way.
        /// </summary>
        private static void AddParameter(IDbCommand cmd, string name, object value)
        {
            var param = cmd.CreateParameter();
            param.ParameterName = name;
            param.Value = value ?? DBNull.Value;
            cmd.Parameters.Add(param);
        }
    }
}
