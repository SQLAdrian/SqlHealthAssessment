// SQLite support disabled — uncomment System.Data.SQLite in .csproj to re-enable
//
// using System.Data;
// using System.Data.SQLite;
//
// namespace LiveMonitor.Data
// {
//     public class SqliteConnectionFactory : IDbConnectionFactory
//     {
//         private readonly string _connectionString;
//
//         public SqliteConnectionFactory(string connectionString)
//         {
//             _connectionString = connectionString;
//         }
//
//         public IDbConnection CreateConnection() => new SQLiteConnection(_connectionString);
//         public string DataSourceType => "Sqlite";
//     }
// }
