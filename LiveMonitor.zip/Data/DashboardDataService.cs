using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using LiveMonitor.Data.Models;

namespace LiveMonitor.Data
{
    /// <summary>
    /// High-level data service that provides typed dashboard data.
    /// Wraps QueryExecutor to map raw query results to domain models.
    /// </summary>
    public class DashboardDataService
    {
        private readonly QueryExecutor _executor;

        public DashboardDataService(QueryExecutor executor)
        {
            _executor = executor ?? throw new ArgumentNullException(nameof(executor));
        }

        // ================================================================
        // INSTANCES
        // ================================================================

        /// <summary>
        /// Returns the list of active SQL Server instances available for monitoring.
        /// </summary>
        public async Task<string[]> GetInstancesAsync()
        {
            // Use a minimal filter since the instances query does not use time/instance params
            var filter = new DashboardFilter();
            var dt = await _executor.ExecuteQueryAsync("instances.list", filter);
            return dt.Rows.Cast<DataRow>()
                .Select(r => r["sql_instance"]?.ToString() ?? "")
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .ToArray();
        }

        

        // ================================================================
        // LONG QUERIES
        // ================================================================

        /// <summary>
        /// Returns long query count over time.
        /// </summary>
        public async Task<List<TimeSeriesPoint>> GetLongQueryTimeSeriesAsync(DashboardFilter filter)
        {
            return await _executor.ExecuteQueryAsync("longquery.timeseries", filter, MapTimeSeriesPoint);
        }

        /// <summary>
        /// Returns the full details table for long-running queries.
        /// </summary>
        public async Task<DataTable> GetLongQueryDetailsAsync(DashboardFilter filter)
        {
            return await _executor.ExecuteQueryAsync("longquery.details", filter);
        }

        /// <summary>
        /// Returns the SQL text and query plan for a specific long query by its ID.
        /// </summary>
        public async Task<string> GetLongQueryTextAsync(DashboardFilter filter, int queryId)
        {
            var extra = new Dictionary<string, object> { ["@QueryId"] = queryId };
            var dt = await _executor.ExecuteQueryAsync("longquery.sqltext", filter, extra);
            if (dt.Rows.Count > 0)
                return dt.Rows[0]["sql_text"]?.ToString() ?? "";
            return "";
        }

        // ================================================================
        // WAIT EVENTS
        // ================================================================

        /// <summary>
        /// Returns wait event duration time series, grouped by category or type
        /// depending on the WaitGrouping setting in the filter.
        /// </summary>
        public async Task<List<TimeSeriesPoint>> GetWaitEventsTimeSeriesAsync(DashboardFilter filter)
        {
            var queryId = filter.WaitGrouping == "Type"
                ? "instance.waits_type"
                : "instance.waits_category";
            return await _executor.ExecuteQueryAsync(queryId, filter, MapTimeSeriesPoint);
        }

        /// <summary>
        /// Returns detailed wait event data as a DataTable.
        /// </summary>
        public async Task<DataTable> GetWaitEventDetailsAsync(DashboardFilter filter)
        {
            return await _executor.ExecuteQueryAsync("waits.details", filter);
        }

       
        // ================================================================
        // SHARED MAPPER
        // ================================================================

        /// <summary>
        /// Maps a data reader row with Time/Series/Value columns to a TimeSeriesPoint.
        /// </summary>
        private static TimeSeriesPoint MapTimeSeriesPoint(IDataReader reader)
        {
            return new TimeSeriesPoint
            {
                Time = ParseDateTime(reader["Time"]),
                Series = reader["Series"]?.ToString() ?? "",
                Value = reader["Value"] != DBNull.Value ? Convert.ToDouble(reader["Value"]) : 0.0
            };
        }

        /// <summary>
        /// Parses a DateTime from either a DateTime object or a string (ISO 8601 format).
        /// </summary>
        private static DateTime ParseDateTime(object? value)
        {
            if (value == null || value == DBNull.Value)
                return DateTime.MinValue;

            if (value is DateTime dt)
                return dt;

            if (DateTime.TryParse(value.ToString(), out var parsed))
                return parsed;

            return DateTime.MinValue;
        }
    }
}
