namespace LiveMonitor.Data.Models
{
    public class CheckStatus
    {
        public string Status { get; set; } = "OK";
        public int Count { get; set; }
    }
}
