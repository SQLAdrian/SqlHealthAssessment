namespace LiveMonitor.Data
{
    public class AutoRefreshService : IDisposable
    {
        private Timer? _timer;
        private int _intervalMs;
        private bool _isRunning;

        public event Action? OnRefresh;

        public bool IsRunning => _isRunning;

        public AutoRefreshService(Microsoft.Extensions.Configuration.IConfiguration config)
        {
            var seconds = int.TryParse(config["RefreshIntervalSeconds"], out var s) ? s : 5;
            _intervalMs = seconds * 1000;
        }

        public void Start()
        {
            if (_isRunning) return;
            _isRunning = true;
            _timer = new Timer(_ => OnRefresh?.Invoke(), null, _intervalMs, _intervalMs);
        }

        public void Stop()
        {
            _isRunning = false;
            _timer?.Dispose();
            _timer = null;
        }

        public void SetInterval(int seconds)
        {
            _intervalMs = seconds * 1000;
            if (_isRunning)
            {
                Stop();
                Start();
            }
        }

        public void Dispose()
        {
            _timer?.Dispose();
        }
    }
}
