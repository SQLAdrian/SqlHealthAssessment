using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using LiveMonitor.Data.Models;

namespace LiveMonitor.Data
{
    /// <summary>
    /// Loads, saves, and queries dashboard configuration from a JSON file.
    /// Falls back to DefaultConfigGenerator when the file is missing or corrupt.
    /// </summary>
    public class DashboardConfigService
    {
        private readonly string _configPath;
        private readonly string _backupPath;
        private DashboardConfigRoot _config;

        private static readonly JsonSerializerOptions SerializerOptions = new()
        {
            WriteIndented = true,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        };

        /// <summary>
        /// Event raised after the configuration has been saved and should be re-rendered.
        /// </summary>
        public event Action? OnConfigChanged;

        /// <summary>
        /// The currently loaded dashboard configuration.
        /// </summary>
        public DashboardConfigRoot Config => _config;

        public DashboardConfigService()
        {
            _configPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "dashboard-config.json");
            _backupPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "dashboard-config.backup.json");
            _config = Load();
        }

        /// <summary>
        /// Loads configuration from disk. If the file does not exist or deserialization fails,
        /// generates defaults, persists them, and returns the default configuration.
        /// </summary>
        private DashboardConfigRoot Load()
        {
            if (File.Exists(_configPath))
            {
                try
                {
                    var json = File.ReadAllText(_configPath);
                    var config = JsonSerializer.Deserialize<DashboardConfigRoot>(json, SerializerOptions);
                    if (config != null)
                        return config;
                }
                catch
                {
                    // Deserialization failed; fall through to default generation.
                }
            }

            var defaultConfig = DefaultConfigGenerator.Generate();
            _config = defaultConfig;
            Save();
            return defaultConfig;
        }

        /// <summary>
        /// Persists the current configuration to disk. Creates a backup of the previous file first.
        /// </summary>
        public void Save()
        {
            if (File.Exists(_configPath))
            {
                File.Copy(_configPath, _backupPath, overwrite: true);
            }

            var json = JsonSerializer.Serialize(_config, SerializerOptions);
            File.WriteAllText(_configPath, json);
        }

        /// <summary>
        /// Fires the <see cref="OnConfigChanged"/> event so subscribers (dashboards) can re-render.
        /// </summary>
        public void NotifyChanged()
        {
            OnConfigChanged?.Invoke();
        }

        /// <summary>
        /// Saves the current configuration and notifies subscribers of the change.
        /// </summary>
        public void SaveAndNotify()
        {
            Save();
            NotifyChanged();
        }

        /// <summary>
        /// Replaces the current configuration with the default, saves it, and notifies subscribers.
        /// </summary>
        public void ResetToDefault()
        {
            _config = DefaultConfigGenerator.Generate();
            Save();
            NotifyChanged();
        }

        /// <summary>
        /// Resolves the SQL query text for a given query identifier and data source type.
        /// Searches panel definitions across all dashboards as well as the support queries dictionary.
        /// </summary>
        /// <param name="queryId">The query/panel identifier (e.g., "repo.perf_counters").</param>
        /// <param name="dataSourceType">"SqlServer" or "Sqlite".</param>
        /// <returns>The SQL query string for the specified data source.</returns>
        /// <exception cref="KeyNotFoundException">Thrown when the query ID is not found.</exception>
        public string GetQuery(string queryId, string dataSourceType)
        {
            // Search panels across all dashboards
            var panel = _config.Dashboards
                .SelectMany(d => d.Panels)
                .FirstOrDefault(p => p.Id == queryId);

            if (panel != null)
            {
                return dataSourceType == "Sqlite" ? panel.Query.Sqlite : panel.Query.SqlServer;
            }

            // Search support queries
            if (_config.SupportQueries.TryGetValue(queryId, out var queryPair))
            {
                return dataSourceType == "Sqlite" ? queryPair.Sqlite : queryPair.SqlServer;
            }

            throw new KeyNotFoundException($"Query '{queryId}' not found in dashboard configuration.");
        }

        /// <summary>
        /// Returns true if the query ID exists in any panel or in the support queries dictionary.
        /// </summary>
        /// <param name="queryId">The query/panel identifier to look up.</param>
        public bool HasQuery(string queryId)
        {
            var inPanels = _config.Dashboards
                .SelectMany(d => d.Panels)
                .Any(p => p.Id == queryId);

            if (inPanels)
                return true;

            return _config.SupportQueries.ContainsKey(queryId);
        }
    }
}
